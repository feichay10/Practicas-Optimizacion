 /*
 *  GRAFO.CPP - Implementaci�n de la clase GRAFOS
 *
 *
 *  Autor : Antonio Sedeno Noda, Sergio Alonso
 *  Fecha : 2013-2020
 */

#include "grafo.h"

GRAFO::~GRAFO()
{

}

void GRAFO:: actualizar (char nombrefichero[85], int &errorapertura)
{

}

unsigned GRAFO::Es_dirigido()
{

}

void GRAFO::Info_Grafo()
{

}

void Mostrar_Lista(vector<LA_nodo> L)
{

}


void GRAFO :: Mostrar_Listas (int l)
{

};

void GRAFO::dfs(unsigned i, vector<bool> &visitado)
{

}

void GRAFO::ComponentesConexas()
{

}

void GRAFO::Kruskal()
{
    vector <AristaPesada> Aristas;

    /*Usaremos la busqueda del menor en cada momento, pues es el mejor para Kruskal que no exige tener todas las aristas ordenadas*/
    /*Cargamos todas las aristas de la lista de adyacencia*/

    Aristas.resize(m);

    unsigned k = 0;
    for (unsigned i = 0; i<n; i++){
        for (unsigned j=0; j<LS[i].size();j++){
            if (i < LS[i][j].j) {
                Aristas[k].extremo1 = i;
                Aristas[k].extremo2 = LS[i][j].j;
                Aristas[k++].peso = LS[i][j].c;
                }
        }
    };
    /*Inicializamos el indice a la cabeza del vector*/
    unsigned head = 0;
    AristaPesada AristaDummy; //Para los intercambios en la ordenacion parcial

    /*Inicializamos el contador de aristas en la soluci�n*/
    unsigned a = 0;

    /*Inicializamos el peso de la solucion*/
    unsigned pesoMST = 0;

    /*Inicializamos el registro de componentes conexas: cada nodo est� en su compomente conexa*/
    vector <unsigned> Raiz;
    Raiz.resize(n);
    for (unsigned q = 0;q < n; q++){
        Raiz[q]=q;
    };
    /*Comenzamos Kruskal*/
    do {
        /* Implementamos el algoritmo de Kruskal */

        } while ((a < (n-1)) && (head < m));

        if (a == (n - 1)){
            cout << "El peso del arbol generador de minimo coste es " << pesoMST << endl;
        }
        else {
            cout << "El grafo no es conexo, y el bosque generador de minimo coste tiene peso " << pesoMST << endl;
        };

}

void GRAFO::ListaPredecesores()
{

}

GRAFO::GRAFO(char nombrefichero[85], int &errorapertura)
{


}





